
// firebaseConfig.js
import { initializeApp } from 'firebase/app';

const firebaseConfig = {
  apiKey: "AIzaSyAesvps_B0juQZyAF1P3Eykv1xGnWD4QUw",
  authDomain: "hustle-and-flow-app.firebaseapp.com",
  projectId: "hustle-and-flow-app",
  storageBucket: "hustle-and-flow-app.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
export default app;
